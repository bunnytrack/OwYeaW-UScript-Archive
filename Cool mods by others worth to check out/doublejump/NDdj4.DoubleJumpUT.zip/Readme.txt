UnrealTournament.ini
No ned add as pakage



[NDdj4.DoubleJumpUT]
maxJumps=3
jumpType=2
jumpHeight=1.900000